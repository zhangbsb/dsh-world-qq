// 原生通道（qq-native 的模块层）的护栏。
//
// 这一层之前一条测试都没有 —— 去重、白名单、开关、回包全靠真机试。这里把传输层换成假的，
// 事件直接灌进来，跑的是真的 home.ask 和真的 agent，所以「有没有花掉一轮」是真数出来的。
import assert from 'node:assert/strict';
import test from 'node:test';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { SessionId } from '@deepseek-ai/dsh-session';
import { hostFixture, textResponse } from './hostFixture.ts';
import { createQqNativeModule, type QqNativeConfig, type QqTransport, type QqTransportOptions } from '../src/ecosystem/qq-native/index.ts';
import { createQqHome } from '../src/ecosystem/qq-native/home.ts';
import { createNativeBridge } from '../src/ecosystem/qq-native/native-bridge.ts';
import { WebSocket } from 'ws';
import { speakerIdentity } from '../src/ecosystem/shared/identity.ts';

const quiet = { info: () => {}, warn: () => {}, error: () => {} };

/** 传输层的替身：记下通道交给它的回调，测试拿它们灌事件。 */
function fakeTransport() {
  const sent: { kind: string; to: string; text: string }[] = [];
  let options: QqTransportOptions | undefined;
  let state = 'closed';
  const factory = (next: QqTransportOptions): QqTransport => {
    options = next;
    return {
      async start() { state = 'online'; },
      async stop() { state = 'closed'; },
      getState: () => state,
      async sendGroup(groupId: string, text: string) { sent.push({ kind: 'group', to: groupId, text }); return { messageId: 'g1' }; },
      async sendPrivate(userId: string, text: string) { sent.push({ kind: 'private', to: userId, text }); return { messageId: 'p1' }; },
    };
  };
  return {
    factory,
    sent,
    emit: (message: unknown) => options?.onPrivateMessage?.(message),
    emitGroup: (message: unknown) => options?.onGroupMessage?.(message),
  };
}

/** 传输层交出来的归一化形状。 */
const incoming = (over: Partial<{ kind: 'group' | 'private'; groupId: string | null; userId: string; messageId: string; selfId: string; text: string; segments: Array<{ type?: string; data?: Record<string, unknown> }> }> = {}) => ({
  kind: 'private' as const, groupId: null, userId: '3475994805', messageId: '7999', selfId: '2039693365', text: '在吗',
  ...over,
});

const configOf = (over: Partial<QqNativeConfig> = {}): QqNativeConfig => ({
  enabled: true,
  transport: 'http',
  httpUrl: 'http://127.0.0.1:1',
  wsUrl: 'ws://127.0.0.1:1',
  accessToken: '',
  pollIntervalMs: 2000,
  whoCanTalk: 'list',
  denyPrivate: [],
  denyGroups: [],
  allowPrivate: ['3475994805'],
  allowGroups: ['681528723'],
  autoReply: true,
  contextMessages: 3,
  bindHomeSession: 'none',
  groupTrigger: 'mention',
  groupKeywords: [],
  replyCooldownSec: 0,
  maxPerMinute: 0,
  replyProbability: 100,
  // 阳台默认关着（端口 0）：绝大多数用例不该顺手起一个服务器。
  bridge: { port: 0, token: '', title: '阳台', contextMessages: 6 },
  ...over,
});

async function settle(ms = 400) { await new Promise(resolve => setTimeout(resolve, ms)); }

test('关掉自动回复就是「收到但不理」：连问都不问，一轮都不花', async t => {
  let turns = 0;
  const { ctx, cleanup } = await hostFixture(t, () => { turns += 1; return textResponse('回完了'); });
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const wire = fakeTransport();
  const channel = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf({ autoReply: false }), logger: quiet, transport: wire.factory });
  channel.start(); cleanup.push(channel.stop);

  wire.emit(incoming());
  await settle();

  assert.equal(turns, 0, '关着自动回复不该有回合');
  assert.equal(wire.sent.length, 0, '也不该往外发东西');
  assert.ok(channel.status().lastEventAt, '但消息确实收到了（lastEventAt 有值）');
});

test('开着自动回复：花一轮，把这轮的话发回同一个人', async t => {
  let turns = 0;
  const { ctx, cleanup } = await hostFixture(t, () => { turns += 1; return textResponse('回完了'); });
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const wire = fakeTransport();
  const channel = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf(), logger: quiet, transport: wire.factory });
  channel.start(); cleanup.push(channel.stop);

  wire.emit(incoming());
  await settle(600);

  assert.equal(turns, 1);
  assert.deepEqual(wire.sent, [{ kind: 'private', to: '3475994805', text: '回完了' }]);
  assert.equal(channel.status().sent, 1);
  assert.equal(channel.status().failed, 0);
});

test('三条不该问的：重复的 id、不在白名单的、她自己发的', async t => {
  let turns = 0;
  const { ctx, cleanup } = await hostFixture(t, () => { turns += 1; return textResponse('回完了'); });
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const wire = fakeTransport();
  const channel = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf(), logger: quiet, transport: wire.factory });
  channel.start(); cleanup.push(channel.stop);

  wire.emit(incoming({ messageId: '8001' }));
  await settle(600);
  assert.equal(turns, 1, '第一条该问');

  wire.emit(incoming({ messageId: '8001' }));                       // 同一条消息的重投
  wire.emit(incoming({ messageId: '8002', userId: '999999' }));     // 不在白名单
  wire.emit(incoming({ messageId: '8003', userId: '2039693365' })); // 她自己发的（回声）
  wire.emit(incoming({ messageId: '' }));                           // 协议里没给 id：不拦，但也别当重复
  await settle(600);
  assert.equal(turns, 2, '只有「没 id 的那条」该再多一次；重复/白名单外/自己的都不算');
});

test('群里说话也走同一条线，回包发回群里', async t => {
  let turns = 0;
  const { ctx, cleanup } = await hostFixture(t, () => { turns += 1; return textResponse('群里回一句'); });
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const wire = fakeTransport();
  const channel = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf(), logger: quiet, transport: wire.factory });
  channel.start(); cleanup.push(channel.stop);

  // 现在群里默认只接被叫到的：给个 @ 段，这条测的是「回包发回群里」而不是闸门。
  wire.emitGroup(incoming({
    kind: 'group', groupId: '681528723', userId: '3997750133', messageId: '9001', text: '@2039693365 大家好',
    segments: [{ type: 'at', data: { qq: '2039693365' } }, { type: 'text', data: { text: ' 大家好' } }],
  }));
  await settle(600);

  assert.equal(turns, 1);
  assert.deepEqual(wire.sent, [{ kind: 'group', to: '681528723', text: '群里回一句' }]);
});


test('群里没叫她就不接：只记上下文，不花一轮', async t => {
  let turns = 0;
  const { ctx, cleanup } = await hostFixture(t, () => { turns += 1; return textResponse('不该被问到'); });
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const wire = fakeTransport();
  const channel = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf(), logger: quiet, transport: wire.factory });
  channel.start(); cleanup.push(channel.stop);

  // 一句普通群聊：没 @、没引用、没关键词
  wire.emitGroup(incoming({ kind: 'group', groupId: '681528723', userId: '3997750133', messageId: '9101', text: '中午吃什么' }));
  await settle(600);

  assert.equal(turns, 0, '没叫到她的群消息不该花一轮');
  assert.equal(wire.sent.length, 0, '也不该往群里冒泡');
  assert.ok(channel.status().lastEventAt, '但消息确实收到了');
});

test('群里被 @ 到、或者有人引用她刚说的话，才递给她', async t => {
  let turns = 0;
  const { ctx, cleanup } = await hostFixture(t, () => { turns += 1; return textResponse('在'); });
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const wire = fakeTransport();
  const channel = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf(), logger: quiet, transport: wire.factory });
  channel.start(); cleanup.push(channel.stop);

  // 被 @：at 段指着她自己的号
  wire.emitGroup(incoming({
    kind: 'group', groupId: '681528723', userId: '3997750133', messageId: '9201', text: '@2039693365 在吗',
    segments: [{ type: 'at', data: { qq: '2039693365' } }, { type: 'text', data: { text: ' 在吗' } }],
  }));
  await settle(600);
  assert.equal(turns, 1, '@ 到她就该接');
  assert.equal(wire.sent.length, 1);

  // 引用她刚回的那句：她发出去的消息 id 是 g1（假传输层固定返回的）
  wire.emitGroup(incoming({
    kind: 'group', groupId: '681528723', userId: '3997750133', messageId: '9202', text: '[引用消息] 这句什么意思',
    segments: [{ type: 'reply', data: { id: 'g1' } }, { type: 'text', data: { text: ' 这句什么意思' } }],
  }));
  await settle(600);
  assert.equal(turns, 2, '有人引用她的话也是冲着她来的');
});

test('命中关键词也算在叫她；私聊不受这个闸门管', async t => {
  let turns = 0;
  const { ctx, cleanup } = await hostFixture(t, () => { turns += 1; return textResponse('在'); });
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const wire = fakeTransport();
  const channel = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf({ groupKeywords: ['大肥鱼'] }), logger: quiet, transport: wire.factory });
  channel.start(); cleanup.push(channel.stop);

  wire.emitGroup(incoming({ kind: 'group', groupId: '681528723', userId: '3997750133', messageId: '9301', text: '大肥鱼呢' }));
  await settle(600);
  assert.equal(turns, 1, '关键词命中就该接');

  // 私聊：不管关键词、不管 @，一律接
  wire.emit(incoming({ messageId: '9302', text: '喂' }));
  await settle(600);
  assert.equal(turns, 2, '私聊照旧每句都接');
});

test('groupTrigger 拨成 all：群里每句都接（逃生口）', async t => {
  let turns = 0;
  const { ctx, cleanup } = await hostFixture(t, () => { turns += 1; return textResponse('在'); });
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const wire = fakeTransport();
  const channel = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf({ groupTrigger: 'all' }), logger: quiet, transport: wire.factory });
  channel.start(); cleanup.push(channel.stop);

  wire.emitGroup(incoming({ kind: 'group', groupId: '681528723', userId: '3997750133', messageId: '9401', text: '随便说一句' }));
  await settle(600);
  assert.equal(turns, 1, 'all 就是老的「句句都接」');
});

test('不在白名单的消息：到过、被挡下，状态里分得出来', async t => {
  let turns = 0;
  const { ctx, cleanup } = await hostFixture(t, () => { turns += 1; return textResponse('不该被问到'); });
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const wire = fakeTransport();
  const channel = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf(), logger: quiet, transport: wire.factory });
  channel.start(); cleanup.push(channel.stop);

  wire.emit(incoming({ userId: '111111', messageId: '9501' }));
  await settle();

  const status = channel.status();
  assert.equal(turns, 0, '不在白名单不该问她');
  assert.equal(status.blocked, 1, '但要记一笔：这条确实到过通道');
  assert.ok(status.lastBlockedAt, '时间戳也留着');
  assert.ok(status.lastEventAt, 'lastEventAt 同时会动 —— 两个数一起看才知道是「送到了但被挡」');
});

test('whoCanTalk: everyone —— 名单外的号也能进来，自动开一间会话并回话', async t => {
  let turns = 0;
  const { ctx, cleanup } = await hostFixture(t, () => { turns += 1; return textResponse('我在，谁呀'); });
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const wire = fakeTransport();
  const channel = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf({ whoCanTalk: 'everyone' }), logger: quiet, transport: wire.factory });
  channel.start(); cleanup.push(channel.stop);

  wire.emit(incoming({ userId: '88888888', messageId: '9601', text: '第一次来找你' }));
  await settle(600);

  assert.equal(turns, 1, 'everyone 模式下陌生号也要问一轮');
  assert.deepEqual(wire.sent, [{ kind: 'private', to: '88888888', text: '我在，谁呀' }], '回话按原路发回那个号');
  assert.equal(channel.status().blocked, 0, '没有黑名单就不该挡');
});

test('whoCanTalk: everyone 也挡黑名单 —— deny 永远优先', async t => {
  let turns = 0;
  const { ctx, cleanup } = await hostFixture(t, () => { turns += 1; return textResponse('不该被问到'); });
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const wire = fakeTransport();
  const channel = createQqNativeModule({
    ctx, home: async () => agent,
    config: () => configOf({ whoCanTalk: 'everyone', denyPrivate: ['666666'] }),
    logger: quiet, transport: wire.factory,
  });
  channel.start(); cleanup.push(channel.stop);

  wire.emit(incoming({ userId: '666666', messageId: '9701' }));
  await settle();

  assert.equal(turns, 0);
  assert.equal(channel.status().blocked, 1, '黑名单里的号记一笔挡下');
});

test('面板上的「连到哪个 QQ 后端」：设置存进 stateFile，数字夹在范围内，令牌只说有没有', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-world-qq-settings-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const { ctx, cleanup } = await hostFixture(t, () => textResponse('在。'));
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const stateFile = join(dir, 'qq-native.json');
  const wire = fakeTransport();
  const channel = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf(), stateFile, logger: quiet, transport: wire.factory });
  channel.start(); cleanup.push(channel.stop);

  channel.setSettings({
    httpUrl: 'http://127.0.0.1:3900/',
    accessToken: 'tok',
    pollIntervalMs: 9,
    whoCanTalk: 'everyone',
    groupTrigger: 'all',
    groupKeywords: ' 大肥鱼，小鱼　',
    denyPrivate: ['111', '111', ' '],
    replyCooldownSec: 999,
    maxPerMinute: 0,
    replyProbability: 150,
    bogus: 'nope',
  });

  const settings = channel.status().settings;
  assert.equal(settings.httpUrl, 'http://127.0.0.1:3900', '尾斜杠去掉');
  assert.equal(settings.hasToken, true, '令牌不回给浏览器');
  assert.equal(settings.pollIntervalMs, 500, '低于下限的轮询间隔夹到 500');
  assert.equal(settings.whoCanTalk, 'everyone');
  assert.equal(settings.groupTrigger, 'all');
  assert.deepEqual(settings.groupKeywords, ['大肥鱼', '小鱼']);
  assert.deepEqual(settings.denyPrivate, ['111']);
  assert.equal(settings.replyCooldownSec, 300);
  assert.equal(settings.maxPerMinute, 1);
  assert.equal(settings.replyProbability, 100);

  const saved = JSON.parse(readFileSync(stateFile, 'utf8')) as Record<string, unknown>;
  assert.equal(saved.httpUrl, 'http://127.0.0.1:3900');
  assert.equal(saved.accessToken, 'tok');
  assert.equal('bogus' in saved, false, '不认识的字段不落盘');

  const again = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf(), stateFile, logger: quiet, transport: wire.factory });
  assert.equal(again.status().settings.whoCanTalk, 'everyone', '重开模块设置还在');
  assert.equal(again.status().settings.hasToken, true);
});


test('她回过的话记成她自己说的：下一轮的上下文里那几句是 assistant', async t => {
  const { ctx, cleanup } = await hostFixture(t, () => textResponse('我在。'));
  const agent = (await ctx.agents.create({ sessionId: SessionId('home'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const wire = fakeTransport();
  const injected: string[] = [];
  ctx.on('session/event', (_session, event) => {
    if (event.type === 'user/message' && (event.data.source ?? {}).kind === 'dsh-world-channel-context') {
      injected.push(String((event.data.content?.[0] as { text?: string } | undefined)?.text ?? ''));
    }
  });
  const channel = createQqNativeModule({ ctx, home: async () => agent, config: () => configOf(), logger: quiet, transport: wire.factory });
  channel.start(); cleanup.push(channel.stop);

  const at = { kind: 'group' as const, groupId: '681528723', segments: [{ type: 'at', data: { qq: '2039693365' } }] };
  wire.emitGroup(incoming({ ...at, messageId: '8101', text: '@大肥鱼 在吗' }));
  await settle(600);
  assert.equal(wire.sent.length, 1, '叫到她了，她回了一句');

  wire.emitGroup(incoming({ ...at, messageId: '8102', text: '@大肥鱼 刚才聊到哪了' }));
  await settle(600);

  assert.equal(injected.length, 1, '第二条进群消息带上了上下文');
  assert.match(injected[0], /"role":"assistant"/, '她说过的那句是 assistant，不是对方说的');
});

test('阳台：外面递一句话进来，她把原话吐回那条线；口令不对连不上', async t => {
  let turns = 0;
  const { ctx, cleanup } = await hostFixture(t, () => { turns += 1; return textResponse('听见了，这条线是通的。'); });
  const agent = (await ctx.agents.create({ sessionId: SessionId('outside'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const dir = mkdtempSync(join(tmpdir(), 'qq-bridge-'));
  cleanup.push(() => rmSync(dir, { recursive: true, force: true }));
  const port = 13210 + Math.floor(Math.random() * 200);
  const token = 'secret-token-0123456789';
  const bridge = createNativeBridge({
    ctx,
    session: async () => agent,
    config: () => ({ port, token, title: '阳台', contextMessages: 4 }),
    worldDir: dir,
    script: 'qq-line.js',
    log: () => {},
  });
  await bridge.start();
  cleanup.push(() => bridge.stop());

  // 口令不对：hello 递上去也不该被留下。
  const rejected = new WebSocket(`ws://127.0.0.1:${port}`);
  const kicked = await new Promise<boolean>(resolve => {
    rejected.on('open', () => rejected.send(JSON.stringify({ kind: 'hello', threadId: 'x', token: 'nope' })));
    rejected.on('close', () => resolve(true));
    setTimeout(() => resolve(false), 3_000);
  });
  assert.equal(kicked, true, '口令不对该被请出去');
  assert.equal(turns, 0, '没进门就不该花一轮');

  // 口令对：递一句话，她把这一轮的原话吐回来。
  const ws = new WebSocket(`ws://127.0.0.1:${port}?token=${token}`);
  const frames: Array<Record<string, unknown>> = [];
  ws.on('message', data => frames.push(JSON.parse(String(data)) as Record<string, unknown>));
  await new Promise<void>(resolve => {
    ws.on('open', () => { ws.send(JSON.stringify({ kind: 'message', threadId: 'line-1', text: '外面有人问，你在吗', from: '外面' })); resolve(); });
  });
  await settle(2_000);

  assert.equal(turns, 1, '递进来的一句话该花一轮');
  const replies = frames.filter(frame => frame.kind === 'reply');
  assert.equal(replies[0]?.hold, true, '收下的那一刻该先回一条 hold，别让门外干等着');
  assert.equal(replies[0]?.text, '');
  const reply = replies.find(frame => frame.text !== '');
  assert.ok(reply, `该收到一条 reply，实际收到 ${JSON.stringify(frames)}`);
  assert.equal(reply.text, '听见了，这条线是通的。');
  const status = bridge.status();
  assert.equal(status.received, 1);
  assert.equal(status.relayed, 1);
  assert.equal(status.spoken, 1);

  // kind 缺省也算一句话（只会写 {"text":"…"} 的程序太多）；重复 hello 不该有任何反应。
  const before = turns;
  ws.send(JSON.stringify({ threadId: 'line-1', text: '再说一句，这次没写 kind', from: '外面' }));
  ws.send(JSON.stringify({ kind: 'hello', threadId: 'line-1', token }));
  await settle(2_000);
  assert.equal(turns, before + 1, 'kind 缺省也该被当成一句话');
  assert.equal(frames.filter(frame => frame.kind === 'error').length, 0, 'hello 不该被当成一句话、退回"text 是空的"');
  assert.equal(bridge.status().received, 2, '两句话都该记上账（hello 不算）');
  assert.deepEqual(bridge.status().threads, ['line-1'], '线名该进上下文表');
  assert.deepEqual(status.threads, ['line-1']);
  assert.equal(status.serving, true);
  assert.match(status.line, /DSH_QQ_BRIDGE_TOKEN=/);
  ws.close();
});


test('阳台：口令写在 URL 里时，对面再发 hello 也收得到 ready', async t => {
  const { ctx, cleanup } = await hostFixture(t, () => textResponse('嗯。'));
  const agent = (await ctx.agents.create({ sessionId: SessionId('outside2'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const dir = mkdtempSync(join(tmpdir(), 'qq-bridge-ready-'));
  cleanup.push(() => rmSync(dir, { recursive: true, force: true }));
  const port = 13460 + Math.floor(Math.random() * 200);
  const token = 'secret-token-ready-0123';
  const bridge = createNativeBridge({
    ctx, session: async () => agent,
    config: () => ({ port, token, title: '阳台', contextMessages: 4 }),
    worldDir: dir, script: 'qq-line.js', log: () => {},
  });
  await bridge.start();
  cleanup.push(() => bridge.stop());

  const ws = new WebSocket(`ws://127.0.0.1:${port}?token=${token}`);
  const frames: Array<Record<string, unknown>> = [];
  ws.on('message', data => frames.push(JSON.parse(String(data)) as Record<string, unknown>));
  await new Promise<void>(resolve => {
    ws.on('open', () => { ws.send(JSON.stringify({ kind: 'hello', threadId: 'line-9', token, from: '外面' })); resolve(); });
  });
  await settle(1_200);
  assert.ok(frames.some(frame => frame.kind === 'ready'), `该收到 ready，实际 ${JSON.stringify(frames)}`);
  assert.equal(frames.filter(frame => frame.kind === 'error').length, 0, 'hello 不该被退回"text 是空的"');
  assert.equal(bridge.status().received, 0, 'hello 不是一句话，不该记账');
  ws.close();
});

test('阳台：线走了以后她说的话记成 dropped，不再混进 spoken', async t => {
  const { ctx, cleanup } = await hostFixture(t, () => textResponse('这句递不出去了。'));
  const agent = (await ctx.agents.create({ sessionId: SessionId('outside3'), agentOptions: { provider: 'test', model: 'test' } })).agent;
  const dir = mkdtempSync(join(tmpdir(), 'qq-bridge-drop-'));
  cleanup.push(() => rmSync(dir, { recursive: true, force: true }));
  const port = 13660 + Math.floor(Math.random() * 200);
  const token = 'secret-token-dropped-01';
  const bridge = createNativeBridge({
    ctx, session: async () => agent,
    config: () => ({ port, token, title: '阳台', contextMessages: 4 }),
    worldDir: dir, script: 'qq-line.js', log: () => {},
  });
  await bridge.start();
  cleanup.push(() => bridge.stop());

  const ws = new WebSocket(`ws://127.0.0.1:${port}?token=${token}`);
  await new Promise<void>(resolve => { ws.on('open', () => resolve()); });
  ws.send(JSON.stringify({ kind: 'message', threadId: 'line-gone', text: '说完这句我就撤', from: '外面' }));
  ws.close();
  await settle(3_000);
  const status = bridge.status();
  assert.equal(status.received, 1);
  assert.equal(status.relayed, 1);
  assert.equal(status.spoken, 0, '线都走了，不该算"说出去了"');
  assert.equal(status.dropped, 1, '没递到要单独记一笔');
});
